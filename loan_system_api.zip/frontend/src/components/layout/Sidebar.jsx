import React, { useState, useEffect, useRef } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Users, 
  UserPlus, 
  Wallet, 
  FileText, 
  Settings, 
  LogOut,
  Building2,
  Users2,
  MessageSquare,
  ChevronDown, Send, BarChart3,
  ShieldAlert,
  ShieldCheck,
  Zap,
  Briefcase,
  Mail,
  X,
  ChevronRight,
  ClipboardList,
  Lock,
  Crown,
  Sliders,
  AlertCircle,
  Upload
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { loanService } from '../../api/api';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import CollapsableSection from './CollapsableSection';
import HelpGuide from '../ui/HelpGuide';
import { useHelpGuide } from '../../hooks/useHelpGuide';
import { 
  fieldOfficerGuide, managerGuide, 
  financeOfficerGuide, adminGuide 
} from '../../data/guideContent';
import { HelpCircle } from 'lucide-react';

function cn(...inputs) {
  return twMerge(clsx(inputs));
}

const Sidebar = ({ isOpen, onClose }) => {
  const { user, logout, activeRole, switchActiveRole } = useAuth();
  const navigate = useNavigate();

  // Poll for new repayments every 15 seconds
  const [newRepaymentCount, setNewRepaymentCount] = useState(0);
  const lastRepaymentCheck = useRef(localStorage.getItem('last_repayment_check') || new Date().toISOString());

  useEffect(() => {
    if (activeRole !== 'FINANCIAL_OFFICER' && activeRole !== 'ADMIN' && activeRole !== 'SUPER_ADMIN') {
      return;
    }
    const checkNewRepayments = async () => {
      try {
        const res = await loanService.api.get(
          `/repayments/unmatched/?since=${lastRepaymentCheck.current}`
        );
        const count = res.data?.new_count || 0;
        setNewRepaymentCount(count);
      } catch (e) {
        // Silent fail
      }
    };

    checkNewRepayments();
    const interval = setInterval(checkNewRepayments, 15000);
    return () => clearInterval(interval);
  }, [activeRole]);

  const getGuide = () => {
    if (activeRole === 'ADMIN' || activeRole === 'SUPER_ADMIN') return adminGuide;
    if (activeRole === 'MANAGER') return managerGuide;
    if (activeRole === 'FINANCIAL_OFFICER') return financeOfficerGuide;
    if (activeRole === 'FIELD_OFFICER') return fieldOfficerGuide;
    return adminGuide;
  };

  const currentGuide = getGuide();
  const { isOpen: guideOpen, openGuide, closeGuide } = useHelpGuide(activeRole || 'admin');

  const handleRoleSwitch = (role) => {
    switchActiveRole(role);
    if (role === 'SUPER_ADMIN') navigate('/admin/super-admins');
    else if (role === 'ADMIN') navigate('/admin/dashboard');
    else if (role === 'MANAGER') navigate('/manager/dashboard');
    else if (role === 'FINANCIAL_OFFICER') navigate('/finance/overview');
    else if (role === 'FIELD_OFFICER') navigate('/field/dashboard');
    
    if (window.innerWidth < 1024) onClose();
  };

  const adminLinks = [
    { to: '/admin/dashboard', icon: LayoutDashboard, label: 'Overview' },
    { to: '/admin/customers', icon: Users, label: 'Customers' },
    { to: '/admin/loans', icon: Wallet, label: 'Loans' },
    { to: '/admin/security-logs', icon: ShieldAlert, label: 'Security Logs' },
    ...(user?.is_owner ? [{ to: '/admin/owner-audit', icon: Crown, label: 'Owner Audit' }] : []),
    { to: '/admin/customer-communicator', icon: MessageSquare, label: 'Customer Comms' },
    { to: '/admin/official-communicator', icon: Mail, label: 'Official Comms' },
  ];

  const managerLinks = [
    { to: '/manager/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
    { to: '/manager/officers', icon: Users2, label: 'Field Officers' },
    { to: '/manager/customers', icon: Users, label: 'Regional Customers' },
    { to: '/manager/customer-communicator', icon: MessageSquare, label: 'Customer Communicator' },
    { to: '/manager/official-communicator', icon: Mail, label: 'Official Communicator' },
  ];

  const officerLinks = [
    { to: '/finance/overview', icon: LayoutDashboard, label: 'Overview' },
    { to: '/finance/disbursement', icon: Send, label: 'Disbursement Queue' },
    { to: '/finance/analytics', icon: BarChart3, label: 'Analytics' },
    { to: '/finance/ledger', icon: FileText, label: 'Ledger' },
    { to: '/finance/unmatched', icon: AlertCircle, label: 'Unmatched Payments', badge: true },
    { to: '/finance/upload', icon: Upload, label: 'Upload Statement' },
    { to: '/finance/reports', icon: ClipboardList, label: 'Reports' },
    { to: '/finance/control', icon: Settings, label: 'Financial Control' },
    { to: '/finance/customer-communicator', icon: MessageSquare, label: 'Customer Comms' },
  ];

  const fieldLinks = [
    { to: '/field/dashboard', icon: LayoutDashboard, label: 'Dashboard' },
  ];

  const baseLinks = activeRole === 'ADMIN' ? adminLinks : 
                activeRole === 'MANAGER' ? managerLinks : 
                activeRole === 'FINANCIAL_OFFICER' ? officerLinks :
                fieldLinks;

  return (
    <>
      {/* Mobile/Tablet Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-40 xl:hidden transition-opacity duration-300"
          onClick={onClose}
        />
      )}

      <aside className={cn(
        "w-64 h-screen bg-white border-r border-slate-200 dark:bg-slate-900 dark:border-slate-800 flex flex-col fixed left-0 top-0 z-50 transition-all duration-300 ease-in-out shadow-2xl xl:shadow-none",
        isOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="p-6 flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-black text-primary-600 dark:text-primary-400 tracking-tighter leading-tight">Azariah Credit Ltd</h1>
            <button 
              onClick={onClose}
              className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all active:scale-95 group"
              title="Close Menu"
            >
              <X className="w-5 h-5 text-slate-500 group-hover:rotate-90 transition-transform" />
            </button>
          </div>

          {/* Role Switcher - ONLY FOR ADMINS with God Mode */}
          {(user?.god_mode_enabled || user?.is_owner) && (
            <div className="mt-2 space-y-1">
              {user?.god_mode_enabled && (
                <div className="mx-0 mb-2 px-3 py-1.5 bg-amber-50 border border-amber-200 rounded-lg flex items-center gap-2">
                  <Zap className="w-3 h-3 text-amber-500" />
                  <span className="text-xs font-bold text-amber-600">
                    {user?.is_owner ? '👑 Owner' : '⚡ God Mode'}
                  </span>
                </div>
              )}
              <div className="flex items-center justify-between px-2 mb-1">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Privileged Access</p>
                <span className="bg-amber-100 text-amber-600 dark:bg-amber-900/30 dark:text-amber-400 text-[9px] px-1.5 py-0.5 rounded-full font-black animate-pulse flex items-center gap-1 border border-amber-200 dark:border-amber-800">
                  <Zap className="w-2.5 h-2.5 fill-current" />
                  GOD MODE
                </span>
              </div>
              <div className="relative group">
                <select 
                  value={activeRole}
                  onChange={(e) => handleRoleSwitch(e.target.value)}
                  className="w-full pl-9 pr-4 py-2 bg-primary-600 text-white rounded-lg text-xs font-bold appearance-none cursor-pointer focus:outline-none focus:ring-2 focus:ring-primary-500/50 shadow-lg shadow-primary-500/20"
                >
                  <option value="ADMIN">God Mode: Admin</option>
                  <option value="SUPER_ADMIN">View: Super Admin</option>
                  <option value="MANAGER">View: Branch Manager</option>
                  <option value="FINANCIAL_OFFICER">View: Finance Officer</option>
                  <option value="FIELD_OFFICER">View: Field Officer</option>
                </select>
                <ShieldCheck className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-primary-200" />
                <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-3 h-3 text-primary-200 pointer-events-none" />
              </div>
            </div>
          )}
        </div>

        <nav className="flex-1 px-4 space-y-1 overflow-y-auto pt-2 no-scrollbar">
          {/* Main Navigation Links */}
          {baseLinks.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              onClick={() => {
                if (window.innerWidth < 1024) onClose();
                if (link.badge) {
                  setNewRepaymentCount(0);
                  localStorage.setItem('last_repayment_check', new Date().toISOString());
                }
              }}
              className={({ isActive }) => cn(
                "flex items-center px-4 py-2.5 text-sm font-medium rounded-lg transition-colors justify-between",
                isActive 
                  ? "bg-primary-50 text-primary-600 dark:bg-primary-900/20 dark:text-primary-400" 
                  : "text-slate-600 hover:bg-slate-50 dark:text-slate-400 dark:hover:bg-slate-800"
              )}
            >
              <div className="flex items-center">
                <link.icon className="w-5 h-5 mr-3" />
                {link.label}
              </div>
              {link.badge && newRepaymentCount > 0 && (
                <span className="bg-red-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded-full min-w-[18px] text-center">
                  {newRepaymentCount > 99 ? '99+' : newRepaymentCount}
                </span>
              )}
            </NavLink>
          ))}
        </nav>

        <div className="flex-1 px-4 space-y-1 overflow-y-auto pt-2 no-scrollbar">
          {activeRole === 'ADMIN' && (
            <div className="pt-4 space-y-1">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-3 mb-2">Staff</p>
              <CollapsableSection 
                icon={Users} 
                label="Officials" 
                setSidebarOpen={(val) => { if (!val && window.innerWidth < 1024) onClose(); }}
                activeClass="bg-primary-50 text-primary-600 dark:bg-primary-900/20 dark:text-primary-400"
                links={[
                  { to: '/admin/field-officers', label: 'Field Officers', icon: Users2 },
                  { to: '/admin/managers', label: 'Managers', icon: Building2 },
                  { to: '/admin/finance-officers', label: 'Finance Officers', icon: Briefcase },
                  { to: '/admin/accounts', label: 'Admins', icon: ShieldCheck },
                  ...((user?.is_owner || user?.is_super_admin) ? [{ to: '/admin/super-admins', label: 'Super Admins', icon: ShieldCheck }] : []),
                ]}
              />

              <div className="pt-2">
                <CollapsableSection 
                    icon={Settings} 
                    label="Settings" 
                    setSidebarOpen={(val) => { if (!val && window.innerWidth < 1024) onClose(); }}
                    activeClass="bg-primary-50 text-primary-600 dark:bg-primary-900/20 dark:text-primary-400"
                    links={[
                        ...((user?.is_owner || user?.is_super_admin) ? [
                            { to: '/admin/settings/mpesa', icon: Wallet, label: 'M-Pesa' },
                            { to: '/admin/settings/sms', icon: MessageSquare, label: 'SMS' },
                        ] : []),
                        { to: '/admin/settings/system', icon: Sliders, label: 'System' },
                        ...(user?.is_owner ? [{ to: '/admin/settings/security', icon: Lock, label: 'Security' }] : []),
                        { to: '/admin/settings/branches', icon: Building2, label: 'Branches' },
                    ]}
                />
              </div>

              <div className="pt-2">
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-3 mb-2">Monitoring</p>
                <NavLink
                  to="/admin/audit"
                  className={({ isActive }) => cn(
                    "flex items-center px-4 py-2.5 text-sm font-medium rounded-lg transition-colors",
                    isActive 
                      ? "bg-primary-50 text-primary-600 font-bold" 
                      : "text-slate-600 hover:bg-slate-50 dark:text-slate-400 dark:hover:bg-slate-800"
                  )}
                >
                  <ClipboardList className="w-5 h-5 mr-3" />
                  Audit Logs
                </NavLink>
                
                <NavLink
                  to="/admin/deactivations"
                  className={({ isActive }) => cn(
                    "flex items-center px-4 py-2.5 text-sm font-medium rounded-lg transition-colors",
                    isActive 
                      ? "bg-primary-50 text-primary-600 font-bold" 
                      : "text-slate-600 hover:bg-slate-50 dark:text-slate-400 dark:hover:bg-slate-800"
                  )}
                >
                  <Lock className="w-5 h-5 mr-3" />
                  Security Requests
                </NavLink>
              </div>
            </div>
          )}
        </div>

        {/* Help Guide Button */}
        <div className="px-4 pb-2">
          <button
            onClick={openGuide}
            className="w-full flex items-center gap-2 px-3 py-2.5 text-sm font-medium text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg transition-colors border border-dashed border-slate-200 dark:border-slate-700"
          >
            <HelpCircle className="w-4 h-4" />
            Help & Guide
          </button>
        </div>

        <div className="p-4 border-t border-slate-200 dark:border-slate-800">
          <div className="bg-slate-50 dark:bg-slate-800/50 rounded-xl p-3">
            <div className="flex items-center gap-3 mb-3 text-left">
              <div className="w-8 h-8 rounded-full bg-primary-100 dark:bg-primary-900/30 flex items-center justify-center text-primary-600 dark:text-primary-400 font-bold text-xs uppercase">
                {user?.full_name?.charAt(0) || user?.username?.charAt(0) || 'U'}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-bold text-slate-900 dark:text-white truncate">{user?.full_name || 'Staff'}</p>
                <p className="text-[10px] text-slate-500 truncate uppercase mt-0.5">{activeRole?.replace(/_/g, ' ')}</p>
              </div>
            </div>
            <button
              onClick={() => {
                if (window.confirm('Are you sure you want to sign out?')) {
                  logout();
                }
              }}
              className="flex items-center w-full px-3 py-2 text-xs font-bold text-red-600 hover:bg-red-50 dark:hover:bg-red-900/10 rounded-lg transition-colors border border-transparent hover:border-red-100"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Sign Out System
            </button>
          </div>
        </div>
      </aside>

      <HelpGuide
        isOpen={guideOpen}
        onClose={closeGuide}
        title={currentGuide.title}
        sections={currentGuide.sections}
        role={currentGuide.role}
      />
    </>
  );
};

export default Sidebar;
